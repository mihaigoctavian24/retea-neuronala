import { useState, useEffect, useRef } from 'react'
import './App.css'

// Simple Neural Network implementation
class NeuralNetwork {
  constructor(inputSize, hiddenSize, outputSize) {
    this.inputSize = inputSize;
    this.hiddenSize = hiddenSize;
    this.outputSize = outputSize;
    
    // Initialize weights randomly
    this.weightsIH = this.randomMatrix(inputSize, hiddenSize);
    this.weightsHO = this.randomMatrix(hiddenSize, outputSize);
    this.biasH = this.randomMatrix(1, hiddenSize);
    this.biasO = this.randomMatrix(1, outputSize);
    
    // For visualization
    this.lastInputs = null;
    this.lastHidden = null;
    this.lastOutputs = null;
  }
  
  randomMatrix(rows, cols) {
    return Array(rows).fill(0).map(() => 
      Array(cols).fill(0).map(() => Math.random() * 2 - 1)
    );
  }
  
  sigmoid(x) {
    return 1 / (1 + Math.exp(-x));
  }
  
  sigmoidDerivative(x) {
    return x * (1 - x);
  }
  
  forward(inputs) {
    this.lastInputs = inputs;
    
    // Input to Hidden
    const hidden = [];
    for (let i = 0; i < this.hiddenSize; i++) {
      let sum = this.biasH[0][i];
      for (let j = 0; j < this.inputSize; j++) {
        sum += inputs[j] * this.weightsIH[j][i];
      }
      hidden.push(this.sigmoid(sum));
    }
    this.lastHidden = hidden;
    
    // Hidden to Output
    const outputs = [];
    for (let i = 0; i < this.outputSize; i++) {
      let sum = this.biasO[0][i];
      for (let j = 0; j < this.hiddenSize; j++) {
        sum += hidden[j] * this.weightsHO[j][i];
      }
      outputs.push(this.sigmoid(sum));
    }
    this.lastOutputs = outputs;
    
    return outputs;
  }
  
  train(inputs, targets, learningRate = 0.1) {
    // Forward pass
    const outputs = this.forward(inputs);
    
    // Calculate output errors
    const outputErrors = targets.map((t, i) => t - outputs[i]);
    
    // Calculate hidden errors
    const hiddenErrors = Array(this.hiddenSize).fill(0);
    for (let i = 0; i < this.hiddenSize; i++) {
      for (let j = 0; j < this.outputSize; j++) {
        hiddenErrors[i] += outputErrors[j] * this.weightsHO[i][j];
      }
    }
    
    // Update weights Hidden -> Output
    for (let i = 0; i < this.hiddenSize; i++) {
      for (let j = 0; j < this.outputSize; j++) {
        const gradient = outputErrors[j] * this.sigmoidDerivative(outputs[j]);
        this.weightsHO[i][j] += learningRate * gradient * this.lastHidden[i];
      }
    }
    
    // Update weights Input -> Hidden
    for (let i = 0; i < this.inputSize; i++) {
      for (let j = 0; j < this.hiddenSize; j++) {
        const gradient = hiddenErrors[j] * this.sigmoidDerivative(this.lastHidden[j]);
        this.weightsIH[i][j] += learningRate * gradient * inputs[i];
      }
    }
    
    // Calculate loss
    const loss = outputErrors.reduce((sum, e) => sum + e * e, 0) / outputErrors.length;
    return { loss, outputs, outputErrors, hiddenErrors };
  }
}

function App() {
  const canvasRef = useRef(null);
  const [nn] = useState(() => new NeuralNetwork(2, 4, 1));
  const [isTraining, setIsTraining] = useState(false);
  const [epoch, setEpoch] = useState(0);
  const [loss, setLoss] = useState(1.0);
  const [learningRate, setLearningRate] = useState(0.5);
  const [animationStep, setAnimationStep] = useState(0);
  const [showWeights, setShowWeights] = useState(true);
  const [currentInput, setCurrentInput] = useState([0.5, 0.5]);
  const [prediction, setPrediction] = useState(null);
  
  // XOR training data
  const trainingData = [
    { input: [0, 0], target: [0] },
    { input: [0, 1], target: [1] },
    { input: [1, 0], target: [1] },
    { input: [1, 1], target: [0] }
  ];
  
  // Draw neural network
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    ctx.clearRect(0, 0, width, height);
    
    // Layer positions
    const layerX = [100, 400, 700];
    const neuronRadius = 25;
    
    // Calculate positions
    const inputY = [height / 3, height * 2 / 3];
    const hiddenY = [height / 5, height * 2 / 5, height * 3 / 5, height * 4 / 5];
    const outputY = [height / 2];
    
    // Draw connections with animated signals
    const drawConnection = (x1, y1, x2, y2, weight, active) => {
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      
      // Color based on weight
      const opacity = active ? 0.8 : 0.2;
      if (weight > 0) {
        ctx.strokeStyle = `rgba(52, 168, 83, ${opacity})`;
      } else {
        ctx.strokeStyle = `rgba(234, 67, 53, ${opacity})`;
      }
      ctx.lineWidth = Math.abs(weight) * 3 + 1;
      ctx.stroke();
      
      // Draw weight value if enabled
      if (showWeights && active) {
        ctx.fillStyle = '#333';
        ctx.font = '10px Arial';
        ctx.fillText(weight.toFixed(2), (x1 + x2) / 2, (y1 + y2) / 2 - 5);
      }
      
      // Animated signal
      if (active && animationStep > 0) {
        const progress = (animationStep % 30) / 30;
        const signalX = x1 + (x2 - x1) * progress;
        const signalY = y1 + (y2 - y1) * progress;
        
        ctx.beginPath();
        ctx.arc(signalX, signalY, 5, 0, Math.PI * 2);
        ctx.fillStyle = weight > 0 ? '#34a853' : '#ea4335';
        ctx.fill();
      }
    };
    
    // Draw Input -> Hidden connections
    for (let i = 0; i < nn.inputSize; i++) {
      for (let j = 0; j < nn.hiddenSize; j++) {
        const active = nn.lastInputs && animationStep > 10;
        drawConnection(
          layerX[0] + neuronRadius, inputY[i],
          layerX[1] - neuronRadius, hiddenY[j],
          nn.weightsIH[i][j],
          active
        );
      }
    }
    
    // Draw Hidden -> Output connections
    for (let i = 0; i < nn.hiddenSize; i++) {
      for (let j = 0; j < nn.outputSize; j++) {
        const active = nn.lastHidden && animationStep > 40;
        drawConnection(
          layerX[1] + neuronRadius, hiddenY[i],
          layerX[2] - neuronRadius, outputY[j],
          nn.weightsHO[i][j],
          active
        );
      }
    }
    
    // Draw neurons
    const drawNeuron = (x, y, label, value, isActive) => {
      // Outer circle
      ctx.beginPath();
      ctx.arc(x, y, neuronRadius, 0, Math.PI * 2);
      
      // Color based on activation
      if (isActive && value !== null) {
        const intensity = Math.floor(value * 255);
        ctx.fillStyle = `rgb(${255 - intensity}, ${255 - intensity}, 255)`;
      } else {
        ctx.fillStyle = '#f0f0f0';
      }
      ctx.fill();
      ctx.strokeStyle = '#333';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Label
      ctx.fillStyle = '#333';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, x, y);
      
      // Value
      if (value !== null) {
        ctx.font = '10px Arial';
        ctx.fillText(value.toFixed(2), x, y + neuronRadius + 15);
      }
    };
    
    // Draw Input layer
    ctx.fillStyle = '#333';
    ctx.font = 'bold 16px Arial';
    ctx.fillText('Input Layer', layerX[0], 30);
    inputY.forEach((y, i) => {
      const value = nn.lastInputs ? nn.lastInputs[i] : null;
      const isActive = animationStep > 0;
      drawNeuron(layerX[0], y, `x${i + 1}`, value, isActive);
    });
    
    // Draw Hidden layer
    ctx.fillText('Hidden Layer', layerX[1], 30);
    hiddenY.forEach((y, i) => {
      const value = nn.lastHidden ? nn.lastHidden[i] : null;
      const isActive = animationStep > 20;
      drawNeuron(layerX[1], y, `h${i + 1}`, value, isActive);
    });
    
    // Draw Output layer
    ctx.fillText('Output Layer', layerX[2], 30);
    outputY.forEach((y, i) => {
      const value = nn.lastOutputs ? nn.lastOutputs[i] : null;
      const isActive = animationStep > 50;
      drawNeuron(layerX[2], y, 'y', value, isActive);
    });
    
  }, [nn, animationStep, showWeights]);
  
  // Animation loop
  useEffect(() => {
    if (isTraining) {
      const interval = setInterval(() => {
        const data = trainingData[epoch % trainingData.length];
        const result = nn.train(data.input, data.target, learningRate);
        setLoss(result.loss);
        setEpoch(e => e + 1);
        setAnimationStep(s => (s + 1) % 60);
      }, 100);
      
      return () => clearInterval(interval);
    }
  }, [isTraining, epoch, learningRate, nn, trainingData]);
  
  const handlePredict = () => {
    const output = nn.forward(currentInput);
    setPrediction(output[0]);
    setAnimationStep(1);
    
    // Animate forward pass
    let step = 0;
    const animate = setInterval(() => {
      setAnimationStep(step++);
      if (step > 60) {
        clearInterval(animate);
        setAnimationStep(0);
      }
    }, 50);
  };
  
  const handleReset = () => {
    const newNN = new NeuralNetwork(2, 4, 1);
    Object.assign(nn, newNN);
    setEpoch(0);
    setLoss(1.0);
    setIsTraining(false);
    setAnimationStep(0);
    setPrediction(null);
  };

  return (
    <div className="app">
      <header>
        <h1>🧠 Rețea Neurală Interactivă - Vizualizare Pas cu Pas</h1>
        <p>Învață cum funcționează o rețea neurală prin vizualizare animată!</p>
      </header>
      
      <div className="container">
        <div className="canvas-container">
          <canvas 
            ref={canvasRef} 
            width={800} 
            height={600}
            style={{ border: '2px solid #ddd', borderRadius: '10px', background: 'white' }}
          />
        </div>
        
        <div className="controls">
          <div className="control-section">
            <h3>🎮 Antrenare (XOR Problem)</h3>
            <div className="stats">
              <div className="stat">
                <span>Epoca:</span>
                <strong>{epoch}</strong>
              </div>
              <div className="stat">
                <span>Loss:</span>
                <strong>{loss.toFixed(4)}</strong>
              </div>
            </div>
            
            <div className="slider-control">
              <label>Learning Rate: {learningRate.toFixed(2)}</label>
              <input 
                type="range" 
                min="0.01" 
                max="1" 
                step="0.01"
                value={learningRate}
                onChange={(e) => setLearningRate(parseFloat(e.target.value))}
              />
            </div>
            
            <div className="button-group">
              <button 
                className={isTraining ? 'stop' : 'start'}
                onClick={() => setIsTraining(!isTraining)}
              >
                {isTraining ? '⏸️ Pauză' : '▶️ Start Antrenare'}
              </button>
              <button onClick={handleReset}>🔄 Reset</button>
            </div>
            
            <div className="checkbox-control">
              <label>
                <input 
                  type="checkbox"
                  checked={showWeights}
                  onChange={(e) => setShowWeights(e.target.checked)}
                />
                Arată greutățile (weights)
              </label>
            </div>
          </div>
          
          <div className="control-section">
            <h3>🎯 Testare Predicție</h3>
            <div className="input-controls">
              <div className="slider-control">
                <label>Input 1: {currentInput[0].toFixed(2)}</label>
                <input 
                  type="range" 
                  min="0" 
                  max="1" 
                  step="0.01"
                  value={currentInput[0]}
                  onChange={(e) => setCurrentInput([parseFloat(e.target.value), currentInput[1]])}
                />
              </div>
              
              <div className="slider-control">
                <label>Input 2: {currentInput[1].toFixed(2)}</label>
                <input 
                  type="range" 
                  min="0" 
                  max="1" 
                  step="0.01"
                  value={currentInput[1]}
                  onChange={(e) => setCurrentInput([currentInput[0], parseFloat(e.target.value)])}
                />
              </div>
            </div>
            
            <button className="predict" onClick={handlePredict}>
              🔮 Prezice
            </button>
            
            {prediction !== null && (
              <div className="prediction-result">
                <strong>Predicție:</strong> {prediction.toFixed(4)}
                <div className="prediction-bar">
                  <div 
                    className="prediction-fill"
                    style={{ width: `${prediction * 100}%` }}
                  />
                </div>
              </div>
            )}
          </div>
          
          <div className="info-section">
            <h3>ℹ️ Cum Funcționează</h3>
            <ul>
              <li><strong>Forward Propagation:</strong> Datele trec prin rețea de la stânga la dreapta</li>
              <li><strong>Conexiuni verzi:</strong> Greutăți pozitive (amplifică semnalul)</li>
              <li><strong>Conexiuni roșii:</strong> Greutăți negative (suprimă semnalul)</li>
              <li><strong>Neuroni albastri:</strong> Activare puternică (valoare apropiată de 1)</li>
              <li><strong>XOR Problem:</strong> Rețeaua învață funcția XOR (0^0=0, 0^1=1, 1^0=1, 1^1=0)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
